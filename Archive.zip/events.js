/**
 * Events
 * A module for event properties.
 *
 * @module events
 */

module.exports = function() {
  'use strict';

  App.Express.get('/sendOffer/:user/:item/:token/:identifier/:price', App.api.send.send);

  App.ChildBot.prototype._onFriendMsg = function (steamID, message, type) { 
      if(type === App.Steam.EChatEntryType.ChatMsg) {
          // Bot.steamFriends.sendMessage(steamID, '');
      }
  }
  
  App.ChildBot.prototype._onFriend = function (steamID, relationship) { 
  }


  App.Bot.steamClient.on('logOnResponse', function(logonResp) {
    console.log('logged on.')
      App.Bot.steamWebLogon.webLogOn(function(webSessionID, cookies) {
          console.log('logged on weblogon.')
          App.Bot.community.setCookies(cookies);
          App.Bot.community.startConfirmationChecker(10000, 'u8OxVY+GJ10IlZ9mlmcrkW/d4B4=');
          console.log('started confirmationInterval.')
      });
  });

  App.Bot.steamUser.on('tradeOffers', function(amount) {
    if(amount > 0) {
      console.log('called');
      App.api.receive.handle();
    }
  });
};