/**
 * Config
 * A module for config properties.
 *
 * @module config
 */

module.exports = function() {
  'use strict';

  return {

    db_path: 'mongodb://localhost:27017/tripleskins',

    db_collections: ['users', 'history', 'items', 'purchased', 'statistics'],

    username: 'potatoeshot',

    password: 'hahalookatthisshit',

    apiKey: '615F3F9D56B2268A431E445A98079D3C',

    twoFactorCode: 'qp36m',

    steamlytics_key: '23e40a7193b8e39a0167d22c27b7e62b',

    /**
     * The port that the app will run on.
     * @type {number}
     */
    port: 8080
  };
};