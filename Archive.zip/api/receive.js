/**
 * Receive API
 *
 * @api recieve
 * @return {Class}
 */

'use strict';

let debug = require('debug')('api_receive');

class receive {

  constructor() {
    debug('exported');
  }

  handle() {
    // Get All Offers so we can handle them.
    App.Bot.offers.getOffers({
      get_received_offers: 1,
      active_only: 1,
      time_historical_cutoff: Math.round(Date.now() / 1000)
    }, (error, body) => {
      if(body && body.response.trade_offers_received && !error) {
        // Loop Through Recieved Offers
        body.response.trade_offers_received.forEach((offer) => {
          debug('handling new offer ' + offer.tradeofferid);
          // Declare item arrays.
          let itemIds,
              finalItems = [];

          // Check if Robbing and Items are CSGO Items
          Promise.all([
            this.robbing(offer),
            this.isCSGO(offer)
          ]).then((newArray) => {
            newArray.splice(0,1);
            itemIds = newArray;
            // Return another promise for inventory comparison
            return this.inventoryComparison(itemIds[0], offer.steamid_other, offer);
          }).then((newArray) => {
            finalItems = newArray;
            // Check Prices
            return this.getPrices(newArray, offer);
          }).catch((err)=> {
            debug(err);
          });
        }); 
      }
    });
  }

  // Check if they are trying to rob
  robbing(offer) {

    return new Promise((resolve, reject) => {
      if (offer.trade_offer_state != 2 || offer.items_to_give) {
        // Reject
        this.decline(offer.tradeofferid);
        let err = offer.tradeofferid + ' tried to rob'
        reject(err);
        return;
      } else {
        // Resolve
        resolve();
      }
    });
  }

  // Checking if Offer Contains ONLY CS:GO Items
  isCSGO(offer) {

    // Return Promise
    return new Promise((resolve, reject) => {
      let allCSGO = true,
          count = 0,
          itemIds = [];

      for (var i = 0; i < offer.items_to_receive.length; i++) {
        let item = offer.items_to_receive[i];
        // App ID 730 is CSGO
        if(item.appid != '730') {
          this.decline(offer.tradeofferid);
          reject(offer.tradeofferid + ' item wasnt a csgo skin / item');
        } else {
          itemIds.push(item.assetid);
        }
      };
      resolve(itemIds);
    });
  }

  // Compare to Inventory
  inventoryComparison(itemIds, partnerID, offer) {

    return new Promise((resolve, reject) => {
      let finalItems = [];
      // Get Inventory of Trader
      App.Bot.offers.loadPartnerInventory({
        partnerSteamId: partnerID,
        appId: 730,
        contextId: 2
      }, (err, docs) => {
        if(err) {
          debug(err);
          reject(err);
          this.decline(offer.tradeofferid);
          return;
        }
        // Compare each id to that of in inventory
        for (var i = 0; i < itemIds.length; i++) {
          for (var x = 0; x < docs.length; x++) {
            if(itemIds[i] == docs[x].id) {
              // Push Info about that item
              finalItems.push({
                'id': docs[x].id,
                'price': 0,
                'img': 'http://cdn.steamcommunity.com/economy/image/' + docs[x].icon_url,
                'market_name': docs[x].market_hash_name,
                'name_colour': docs[x].name_color
              });
            }
          };
        };
        resolve(finalItems);
      });
    });
  }

  // Get Price for Each Item
  getPrices(items, offer) {
    let self = this;
    // Return Promise
    return new Promise((resolve, reject) => {
      let success = true,
          total = 0,
          count = 0;

      debug(items);

      items.forEach(function(item) {
        App.db.items.find({
          'market_name': item.market_name
        }, function(err, docs) {
          let price = 0;

          if(docs[0]) {

            if(docs[0].suggested_amount_avg_raw) {
              price = docs[0].suggested_amount_avg_raw;

            } else if (docs[0].avg_price_7_days_raw) {
              price = docs[0].avg_price_7_days_raw;

            } else {
              self.decline(offer.tradeofferid);
              return;
            }

            if(item.market_name.indexOf('Casey') > -1 || item.market_name.indexOf('Souvenir') > -1 || item.market_name.indexOf('Sticker') > -1 || item.market_name.indexOf('Capsule') > -1) {
              self.decline(offer.tradeofferid);
              return;
            }

            if(price < 0.1) {
              self.decline(offer.tradeofferid);
              return;
            } else {
              total += price;
            }

            if(count == items.length - 1) {
              self.accept(offer.tradeofferid, {
                'total': total,
                'steamid_other': offer.steamid_other
              });
            } else {
              count++;
            }

          } else {
            self.decline(offer.tradeofferid);
            return;
          }
        });
      });
    });
  }

  accept(tradeofferid, docs) {
    debug(tradeofferid + ' now accepting.');
    App.Bot.offers.acceptOffer({tradeOfferId: tradeofferid}, function(err) {
      if(!err) {
        docs.total = Number(docs.total) * 1000 * 0.91;
        let identifier = 'http://steamcommunity.com/openid/id/' + docs.steamid_other;

        App.db.users.update({
          'identifier': identifier
        }, {
          $inc: {
            'coins': Number(docs.total),
            'stats.deposited': Number(docs.total)
          },
          $push: {
            'history': {
              'type': 'deposit',
              'amount': docs.total,
              'time': new Date().toString()
            }
          }
        });

        App.db.statistics.update({
          'type': 'stats'
        }, {
          $inc: {
            'deposited': Number(docs.total)
          }
        });

        debug('offer: ' + tradeofferid + ' was accepted for: ' + docs.total + ' credits.');
      } else {
        debug('Error with trade: ' + err);
      }
    });
  }

  // Decline offer
  decline(tradeofferid) {
    debug('declined offer: ' + tradeofferid);
    App.Bot.offers.declineOffer({tradeOfferId: tradeofferid});
  }

}

module.exports = receive;
