/**
 * Send API
 *
 * @api send
 * @return {Class}
 */

'use strict';

let debug = require('debug')('api_send');

class send {

  constructor() {
    debug('exported');
  }

  send(req, res) {
    debug('send');

    let user = req.params.user,
      item = req.params.item,
      token = req.params.token,
      price = req.params.price,
      identifier = 'http://steamcommunity.com/openid/id/' + req.params.identifier;

    debug(user, item, token, identifier);

    App.Bot.offers.makeOffer({
      partnerSteamId: user,
      accessToken: token,
      itemsFromMe: [{
        'appid': 730,
        'contextid': '2',
        'amount': 1,
        'assetid': String(item)
      }],
      itemsFromThem: []
    }, function(err, offerid) {
      debug(offerid);
      if(!err) {
        App.db.users.find({
          'identifier': identifier
        }, function(err, docs) {

          App.db.statistics.update({
            'type': 'stats'
          }, {
            $inc: {
              'withdrawn': Number(price)
            }
          });

          App.db.users.update({
            'identifier': identifier
          }, {
            $set: {
              'coins': (Number(docs[0].coins) - (Number(price)))
            },
            $push: {
              'history': {
                'type': 'buy',
                'amount': price,
                'time': new Date().toString()
              }
            }
          }, function() {
            res.send({
              'success': true,
              'message': 'https://steamcommunity.com/tradeoffer/' + offerid.tradeofferid
            });
          });

        });
      } else {
        res.send(err);
      }
    });
  }

}

module.exports = send;