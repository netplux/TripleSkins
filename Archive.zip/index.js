// TripleSkins Bot

'use strict';

// Single, Global App Variable.
global.App = {};

process.env.DEBUG = 'index, api_receive, api_send, api_utils, api_send';

let debug = require('debug')('index');

/**
 * Require Express dependency.
 * Run express dependency on alias.
 * @see {@link http://expressjs.com/4x/api.html}
 */

const express = require('express');
App.Express = express();
debug('Express dependency loaded.');

/**
 * Assign steam-totp an alias.
 * This lightweight module generates Steam-style 5-digit alphanumeric two-factor authentication code.
 * @see {@link https://github.com/DoctorMcKay/node-steam-totp}
 */
App.SteamTotp = require('steam-totp');
debug('steam-totp required');

/**
 * Assign steam-parentbot an alias.
 * A module that provides a simple base class for a Steam bot.
 * @see {@link https://github.com/dragonbanshee/node-steam-parentbot}
 */
App.ParentBot = require('steam-parentbot');
debug('steam-parentbot required');

/**
 * Assign request an alias.
 * Simplified HTTP request client.
 * @see {@link https://www.npmjs.com/package/request}
 */
App.request = require('sync-request');
debug('request required');

/** Initialise config */
App.config = require('./config.js')();
debug('config initialised');

/** Initialise database */
App.db = require('mongojs')(App.config.db_path, App.config.db_collections);
debug('db initialised.');

App.Steam = App.ParentBot.Steam; //instance of the Steam object

App.ChildBot = function () {
    // Create Child Bot
    App.ChildBot.super_.apply(this, arguments);
};

let util = require('util');

util.inherits(App.ChildBot, App.ParentBot);
debug('Childbot inherited.')

// Initialise App.ChildBot
App.Bot = new App.ChildBot(App.config.username, App.config.password, {
  apikey: App.config.apiKey,
  twoFactorCode: App.config.twoFactorCode,
  identitySecret: 'u8OxVY+GJ10IlZ9mlmcrkW/d4B4=',
  confirmationInterval: 10000
});
debug('Childbot Initialised');


/** Initialise APIs */
App.api = App.api || {};

App.api.receive = require('./api/receive.js');
App.api.receive = new App.api.receive();

App.api.send = require('./api/send.js');
App.api.send = new App.api.send();

/** Initialise Events */
App.events = require('./events.js')();
debug('events initialised');

App.Bot.connect();

/** Start server listening on configured port */
App.Express.listen(8080);
debug('running on port ' + 8080 + '.');